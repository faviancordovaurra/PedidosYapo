// Archivo: build.gradle.kts (nivel raíz)

buildscript {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }

    dependencies {
        // 🔧 Plugins base del proyecto
        classpath("com.android.tools.build:gradle:8.7.0")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.0.21")
        // 🚫 KSP eliminado — ya se aplica desde app/build.gradle.kts
    }
}

// 🧹 Tarea de limpieza del proyecto (sin deprecated API)
tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
