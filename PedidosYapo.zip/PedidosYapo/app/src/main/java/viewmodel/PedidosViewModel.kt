package com.pedidosyapo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.entity.Restaurante
import com.pedidosyapo.repository.PedidosRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PedidosViewModel(private val repository: PedidosRepository) : ViewModel() {

    // Flujos de datos observables
    val productos = repository.obtenerProductos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val restaurantes = repository.obtenerRestaurantes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pedidos = repository.obtenerPedidos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Productos ---
    fun agregarProducto(producto: Producto) = viewModelScope.launch {
        repository.agregarProducto(producto)
    }

    fun eliminarProducto(producto: Producto) = viewModelScope.launch {
        repository.eliminarProducto(producto)
    }

    // --- Restaurantes ---
    fun agregarRestaurante(restaurante: Restaurante) = viewModelScope.launch {
        repository.agregarRestaurante(restaurante)
    }

    fun eliminarRestaurante(restaurante: Restaurante) = viewModelScope.launch {
        repository.eliminarRestaurante(restaurante)
    }

    // --- Pedidos ---
    fun agregarPedido(pedido: Pedido) = viewModelScope.launch {
        repository.agregarPedido(pedido)
    }

    fun eliminarPedido(pedido: Pedido) = viewModelScope.launch {
        repository.eliminarPedido(pedido)
    }
}
