package com.pedidosyapo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.repository.PedidosRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PedidosViewModel(private val repository: PedidosRepository) : ViewModel() {

    private val _pedidos = MutableStateFlow<List<Pedido>>(emptyList())
    val pedidos: StateFlow<List<Pedido>> = _pedidos

    init {
        cargarPedidos()
    }

    private fun cargarPedidos() {
        viewModelScope.launch {
            _pedidos.value = repository.getAllPedidos()
        }
    }

    fun agregarPedido(fecha: String, total: Double) {
        val nuevoPedido = Pedido(id = 0, fecha = fecha, total = total)
        viewModelScope.launch {
            repository.insertPedido(nuevoPedido)
            cargarPedidos()
        }
    }

    fun eliminarPedido(pedido: Pedido) {
        viewModelScope.launch {
            repository.deletePedido(pedido)
            cargarPedidos()
        }
    }
}

