package com.pedidosyapo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.repository.ProductosRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ProductoViewModel(private val repository: ProductosRepository) : ViewModel() {

    // Estado reactivo que contiene la lista de productos
    private val _productos = MutableStateFlow<List<Producto>>(emptyList())
    val productos: StateFlow<List<Producto>> = _productos

    init {
        cargarProductos()
    }

    // 🔹 Cargar todos los productos desde la BD
    private fun cargarProductos() {
        viewModelScope.launch {
            _productos.value = repository.getAllProductos()
        }
    }

    // 🔹 Agregar un nuevo producto
    fun agregar(nombre: String, precio: Double) {
        viewModelScope.launch {
            val nuevoProducto = Producto(
                id = 0,
                nombre = nombre,
                precio = precio
            )
            repository.insertProducto(nuevoProducto)
            cargarProductos() // refresca la lista
        }
    }

    // 🔹 Eliminar producto existente
    fun eliminar(producto: Producto) {
        viewModelScope.launch {
            repository.deleteProducto(producto)
            cargarProductos() // refresca la lista
        }
    }
}

