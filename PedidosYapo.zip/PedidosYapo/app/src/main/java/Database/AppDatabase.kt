package com.pedidosyapo.Database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.pedidosyapo.Dao.PedidoDao
import com.pedidosyapo.Dao.ProductoDao
import com.pedidosyapo.Dao.RestauranteDao
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.entity.Restaurante

@Database(
    entities = [Pedido::class, Producto::class, Restaurante::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun pedidoDao(): PedidoDao
    abstract fun productoDao(): ProductoDao
    abstract fun restauranteDao(): RestauranteDao

    companion object {
        // Instancia única (singleton)
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pedidosyapo_db"
                )
                    .fallbackToDestructiveMigration() // elimina datos si cambia el esquema
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
