package com.pedidosyapo.Database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.pedidosyapo.Dao.PedidoDao
import com.pedidosyapo.Dao.ProductoDao
import com.pedidosyapo.Dao.RestauranteDao
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.entity.Restaurante
import com.pedidosyapo.utils.Converters

@Database(
    entities = [Producto::class, Restaurante::class, Pedido::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productoDao(): ProductoDao
    abstract fun restauranteDao(): RestauranteDao
    abstract fun pedidoDao(): PedidoDao
}
