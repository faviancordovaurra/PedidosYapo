package com.pedidosyapo.repository

import com.pedidosyapo.Dao.PedidoDao
import com.pedidosyapo.Dao.ProductoDao
import com.pedidosyapo.Dao.RestauranteDao
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.entity.Restaurante
import kotlinx.coroutines.flow.Flow

class PedidosRepository(
    private val productoDao: ProductoDao,
    private val restauranteDao: RestauranteDao,
    private val pedidoDao: PedidoDao
) {

    // Productos
    fun obtenerProductos(): Flow<List<Producto>> = productoDao.obtenerProductos()
    suspend fun agregarProducto(producto: Producto) = productoDao.insertarProducto(producto)
    suspend fun eliminarProducto(producto: Producto) = productoDao.eliminarProducto(producto)

    // Restaurantes
    fun obtenerRestaurantes(): Flow<List<Restaurante>> = restauranteDao.obtenerRestaurantes()
    suspend fun agregarRestaurante(restaurante: Restaurante) = restauranteDao.insertarRestaurante(restaurante)
    suspend fun eliminarRestaurante(restaurante: Restaurante) = restauranteDao.eliminarRestaurante(restaurante)

    // Pedidos
    fun obtenerPedidos(): Flow<List<Pedido>> = pedidoDao.obtenerPedidos()
    suspend fun agregarPedido(pedido: Pedido) = pedidoDao.insertarPedido(pedido)
    suspend fun eliminarPedido(pedido: Pedido) = pedidoDao.eliminarPedido(pedido)
}
