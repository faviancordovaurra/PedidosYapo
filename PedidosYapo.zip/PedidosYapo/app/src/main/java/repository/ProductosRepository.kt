package com.pedidosyapo.repository

import com.pedidosyapo.Dao.ProductoDao
import com.pedidosyapo.entity.Producto

class ProductosRepository(private val productoDao: ProductoDao) {

    suspend fun getAllProductos(): List<Producto> = productoDao.getAll()

    suspend fun insertProducto(producto: Producto) = productoDao.insert(producto)

    suspend fun deleteProducto(producto: Producto) = productoDao.delete(producto)
}
