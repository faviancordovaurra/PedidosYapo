package com.pedidosyapo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.entity.PedidoDetalle
import com.pedidosyapo.repository.PedidoRepository
import com.pedidosyapo.repository.PedidoDetalleRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class PedidosViewModel(
    private val repo: PedidoRepository,
    private val detalleRepo: PedidoDetalleRepository
) : ViewModel() {

    // Flujo reactivo de pedidos
    val pedidos: StateFlow<List<Pedido>> = repo.getAllPedidos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * Registrar un nuevo pedido con validación
     * Retorna true si fue exitoso, false si hubo error o carrito vacío
     */
    fun registrarPedidoSeguro(
        total: Double,
        cartItems: List<com.pedidosyapo.entity.CartItem>,
        onResult: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            if (cartItems.isEmpty()) {
                onResult(false) //  No hay productos
                return@launch
            }

            try {
                val pedido = Pedido(
                    cliente = "Cliente Genérico",
                    direccion = "Curacaví, Santiago",
                    fecha = LocalDate.now().toString(),
                    estado = "Completado",
                    total = total
                )

                val pedidoId: Long = repo.insertPedido(pedido)

                val detalles = cartItems.map {
                    PedidoDetalle(
                        pedidoId = pedidoId,
                        nombreProducto = it.nombre,
                        cantidad = it.cantidad,
                        precioUnitario = it.precio,
                        subtotal = it.subtotal
                    )
                }

                detalleRepo.insertarDetalles(detalles)
                onResult(true)
            } catch (e: Exception) {
                e.printStackTrace()
                onResult(false)
            }
        }
    }

    /**
     *  Obtener detalles de un pedido
     */
    fun obtenerDetalles(pedidoId: Long, callback: (List<PedidoDetalle>) -> Unit) {
        viewModelScope.launch {
            val detalles = detalleRepo.obtenerDetalles(pedidoId)
            callback(detalles)
        }
    }

    /**
     *  Eliminar un pedido junto con sus detalles
     */
    fun eliminarPedido(id: Long) {
        viewModelScope.launch {
            detalleRepo.eliminarPorPedidoId(id)
            repo.eliminarPedido(id)
        }
    }
}
