package com.pedidosyapo.repository

import com.pedidosyapo.dao.ProductoDao
import com.pedidosyapo.entity.Producto
import kotlinx.coroutines.flow.Flow

class ProductosRepository(private val productoDao: ProductoDao) {

    fun getAllProductos(): Flow<List<Producto>> = productoDao.getAllProductos()

    suspend fun insertProducto(producto: Producto) {
        // 🔹 Llamada corregida
        productoDao.insert(producto)
    }

    suspend fun updateProducto(producto: Producto) {
        productoDao.update(producto)
    }

    suspend fun deleteProducto(producto: Producto) {
        productoDao.delete(producto)
    }

    suspend fun deleteProductoById(id: Long) {
        productoDao.deleteById(id)
    }
}
