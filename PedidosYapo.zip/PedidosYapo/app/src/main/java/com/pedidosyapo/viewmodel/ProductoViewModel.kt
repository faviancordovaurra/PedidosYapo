package com.pedidosyapo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.repository.ProductosRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ProductoViewModel(
    private val repository: ProductosRepository
) : ViewModel() {

    private val _productos = MutableStateFlow<List<Producto>>(emptyList())
    val productos: StateFlow<List<Producto>> = _productos.asStateFlow()

    init {
        // Carga inicial de productos
        viewModelScope.launch {
            repository.getAllProductos().collect { lista ->
                _productos.value = lista
            }
        }
    }


    fun agregarProducto(producto: Producto) {
        viewModelScope.launch {
            repository.insertProducto(producto)
        }
    }


    fun eliminarProducto(producto: Producto) {
        viewModelScope.launch {
            repository.deleteProducto(producto)
        }
    }


    fun actualizarProducto(producto: Producto) {
        viewModelScope.launch {
            repository.updateProducto(producto)
        }
    }
}
