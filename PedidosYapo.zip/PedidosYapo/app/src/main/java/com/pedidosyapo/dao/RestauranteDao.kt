package com.pedidosyapo.dao

import androidx.room.*
import com.pedidosyapo.entity.Restaurante
import kotlinx.coroutines.flow.Flow

@Dao
interface RestauranteDao {

    @Query("SELECT * FROM restaurante")
    fun getAllRestaurantes(): Flow<List<Restaurante>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(restaurante: Restaurante)

    @Update
    suspend fun update(restaurante: Restaurante)

    @Delete
    suspend fun delete(restaurante: Restaurante)

    @Query("DELETE FROM restaurante WHERE id = :id")
    suspend fun deleteById(id: Long)
}
