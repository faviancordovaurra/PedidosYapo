package com.pedidosyapo.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.pedidosyapo.dao.*
import com.pedidosyapo.entity.*

@Database(
    entities = [
        Producto::class,
        Restaurante::class,
        Pedido::class,
        PedidoItem::class,
        MenuItem::class,
        CartItem::class,
        PedidoDetalle::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    // DAOs
    abstract fun productoDao(): ProductoDao
    abstract fun restauranteDao(): RestauranteDao
    abstract fun pedidoDao(): PedidoDao
    abstract fun pedidoItemDao(): PedidoItemDao
    abstract fun menuItemDao(): MenuItemDao
    abstract fun cartDao(): CartDao
    abstract fun pedidoDetalleDao(): PedidoDetalleDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pedidosyapo_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}
