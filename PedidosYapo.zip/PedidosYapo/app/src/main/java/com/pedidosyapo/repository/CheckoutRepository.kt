package com.pedidosyapo.repository

import com.pedidosyapo.dao.CartDao
import com.pedidosyapo.entity.CartItem
import kotlinx.coroutines.flow.Flow

class CheckoutRepository(private val dao: CartDao) {

    //  Obtener todos los ítems del carrito
    fun getCartItems(): Flow<List<CartItem>> = dao.getAll()

    //  Calcular el total
    fun getTotal(): Flow<Double> = dao.getTotal()

    // Agregar ítem al carrito
    suspend fun addToCart(productoId: Long, nombre: String, precio: Double, cantidad: Int) {
        val subtotal = cantidad * precio
        val item = CartItem(
            menuItemId = productoId,
            nombre = nombre,
            precio = precio,
            cantidad = cantidad,
            subtotal = subtotal
        )
        dao.insert(item)
    }

    //  Eliminar por ID
    suspend fun deleteById(id: Long) = dao.deleteById(id)

    //  Vaciar carrito
    suspend fun clearCart() = dao.clearCart()
}
