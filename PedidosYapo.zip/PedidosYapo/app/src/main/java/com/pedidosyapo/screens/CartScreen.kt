package com.pedidosyapo.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pedidosyapo.entity.CartItem
import com.pedidosyapo.viewmodel.CartViewModel
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    cartVm: CartViewModel,
    onCheckout: () -> Unit
) {
    var cartItems by remember { mutableStateOf(emptyList<CartItem>()) }

    //  Observa los cambios en el flujo del carrito
    LaunchedEffect(Unit) {
        cartVm.allItems.collectLatest { items ->
            cartItems = items
        }
    }

    //  Calcular total dinámicamente
    val total = remember(cartItems) { cartItems.sumOf { it.precio * it.cantidad } }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("🛒 Carrito de Compras") }
            )
        },
        bottomBar = {
            if (cartItems.isNotEmpty()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Total: $${"%.2f".format(total)}",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.align(Alignment.End)
                    )

                    Spacer(Modifier.height(8.dp))

                    Button(
                        onClick = onCheckout,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text("Finalizar compra (${cartItems.size} productos)")
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Tu carrito está vacío 🛍️",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(cartItems, key = { it.id }) { item ->
                        CartItemCard(item)
                    }
                }
            }
        }
    }
}

@Composable
fun CartItemCard(item: CartItem) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("${item.nombre} x${item.cantidad}")
                Text("Subtotal: $${"%.2f".format(item.subtotal)}")
            }
            Text(
                "$${"%.2f".format(item.precio * item.cantidad)}",
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
