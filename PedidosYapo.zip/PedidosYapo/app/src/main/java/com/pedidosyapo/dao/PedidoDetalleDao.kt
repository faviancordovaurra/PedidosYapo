package com.pedidosyapo.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.pedidosyapo.entity.PedidoDetalle

@Dao
interface PedidoDetalleDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarDetalles(detalles: List<PedidoDetalle>)


    @Query("SELECT * FROM pedido_detalle WHERE pedidoId = :pedidoId")
    suspend fun obtenerDetallesPorPedido(pedidoId: Long): List<PedidoDetalle>


    @Query("DELETE FROM pedido_detalle WHERE pedidoId = :pedidoId")
    suspend fun eliminarPorPedidoId(pedidoId: Long)
}
