package com.pedidosyapo.repository

import com.pedidosyapo.dao.RestauranteDao
import com.pedidosyapo.entity.Restaurante
import kotlinx.coroutines.flow.Flow

class RestaurantesRepository(private val dao: RestauranteDao) {

    val restaurantes: Flow<List<Restaurante>> = dao.getAllRestaurantes()

    suspend fun agregar(nombre: String, direccion: String, telefono: String) {
        val restaurante = Restaurante(
            nombre = nombre,
            direccion = direccion,
            telefono = telefono
        )
        dao.insert(restaurante)
    }

    suspend fun eliminar(id: Long) {
        dao.deleteById(id)
    }
}
