package com.pedidosyapo.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.pedidosyapo.entity.MenuItem

@Dao
interface MenuItemDao {

    @Query("SELECT * FROM MenuItem WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): MenuItem?

    @Query("SELECT * FROM MenuItem WHERE restauranteId = :restId")
    suspend fun getByRestaurante(restId: Long): List<MenuItem>

    @Insert
    suspend fun insertAll(items: List<MenuItem>)


}
