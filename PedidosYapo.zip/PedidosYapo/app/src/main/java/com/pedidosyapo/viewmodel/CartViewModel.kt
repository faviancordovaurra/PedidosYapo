package com.pedidosyapo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.CartItem
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.repository.CartRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CartViewModel(private val repo: CartRepository) : ViewModel() {

    // Observa los ítems del carrito en tiempo real
    val allItems: StateFlow<List<CartItem>> = repo.getAllItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Agregar ítem al carrito manualmente
    fun agregarAlCarrito(item: CartItem) {
        viewModelScope.launch {
            repo.insertItem(item)
        }
    }

    // Eliminar ítem específico
    fun eliminarItem(item: CartItem) {
        viewModelScope.launch {
            repo.deleteItem(item)
        }
    }

    // Eliminar ítem por ID
    fun eliminarPorId(id: Long) {
        viewModelScope.launch {
            repo.deleteItemById(id)
        }
    }

    // Vaciar todo el carrito
    fun limpiarCarrito() {
        viewModelScope.launch {
            repo.clearCart()
        }
    }

    // Calcular total del carrito
    val total = repo.getTotal()

    // Nueva función: Agregar producto directamente desde la pantalla de productos
    fun agregarAlCarritoDesdeProducto(producto: Producto) {
        val item = CartItem(
            menuItemId = producto.id, // Se asocia el ID del producto
            nombre = producto.nombre,
            precio = producto.precio,
            cantidad = 1, // Agrega una unidad por defecto
            subtotal = producto.precio // subtotal = precio * cantidad
        )
        agregarAlCarrito(item)
    }
    fun agregarAlCarritoDesdeProducto(producto: Producto, cantidad: Int) {
        viewModelScope.launch {
            val subtotal = producto.precio * cantidad
            val item = CartItem(
                menuItemId = producto.id,
                nombre = producto.nombre,
                precio = producto.precio,
                cantidad = cantidad,
                subtotal = subtotal
            )
            repo.insertItem(item)
        }
    }

}
