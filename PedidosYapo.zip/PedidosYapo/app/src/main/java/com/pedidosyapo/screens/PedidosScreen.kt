package com.pedidosyapo.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.entity.PedidoDetalle
import com.pedidosyapo.viewmodel.PedidosViewModel
import com.pedidosyapo.showNotification

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PedidosScreen(pedidosVm: PedidosViewModel) {
    val pedidos by pedidosVm.pedidos.collectAsState(initial = emptyList())
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Historial de Pedidos", style = MaterialTheme.typography.headlineMedium)

            if (pedidos.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No hay pedidos registrados aún")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(pedidos) { pedido ->
                        PedidoCard(pedido, pedidosVm, snackbarHostState, context)
                    }
                }
            }
        }
    }
}

@Composable
fun PedidoCard(
    pedido: Pedido,
    pedidosVm: PedidosViewModel,
    snackbarHostState: SnackbarHostState,
    context: Context
) {
    var expanded by remember { mutableStateOf(false) }
    var detalles by remember { mutableStateOf(emptyList<PedidoDetalle>()) }
    var mostrarSnackbar by remember { mutableStateOf(false) }

    //  Mostrar snackbar fuera de onClick
    if (mostrarSnackbar) {
        LaunchedEffect(Unit) {
            snackbarHostState.showSnackbar("Pedido eliminado correctamente")
            mostrarSnackbar = false
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("Fecha: ${pedido.fecha}")
            Text("Total: $${"%.0f".format(pedido.total)}")
            Text("Estado: ${pedido.estado}")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = {
                    expanded = !expanded
                    if (expanded) {
                        pedidosVm.obtenerDetalles(pedido.id) { lista ->
                            detalles = lista
                        }
                    }
                }) {
                    Icon(
                        if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null
                    )
                    Text(if (expanded) "Ocultar detalles" else "Ver detalles")
                }

                IconButton(onClick = {
                    pedidosVm.eliminarPedido(pedido.id)
                    mostrarSnackbar = true
                }) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Eliminar pedido",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    if (detalles.isEmpty()) {
                        Text("Cargando productos...")
                    } else {
                        detalles.forEach {
                            Text("- ${it.nombreProducto} x${it.cantidad} = $${"%.0f".format(it.subtotal)}")
                        }

                        //  Notificación + Toast
                        showNotification(context, "Pedido #${pedido.id}", "Total: $${pedido.total}")
                        Toast.makeText(context, "Detalles cargados", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}
