package com.pedidosyapo.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.pedidosyapo.screens.ProductosScreen
import com.pedidosyapo.screens.PedidosScreen
import com.pedidosyapo.showNotification
import com.pedidosyapo.viewmodel.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    productoVm: ProductoViewModel,
    pedidosVm: PedidosViewModel,
    cartVm: CartViewModel
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Productos", "Pedidos", "Carrito")

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Pedidos Yapo") })
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            //  Navegación por pestañas
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        text = { Text(title) },
                        selected = selectedTab == index,
                        onClick = { selectedTab = index }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            //  Contenido dinámico según pestaña seleccionada
            when (selectedTab) {
                0 -> ProductosScreen(viewModel = productoVm, cartVm = cartVm)
                1 -> PedidosScreen(pedidosVm = pedidosVm)
                2 -> CarritoScreen(cartVm = cartVm, pedidosVm = pedidosVm)
            }
        }
    }
}

@Composable
fun CarritoScreen(
    cartVm: CartViewModel,
    pedidosVm: PedidosViewModel
) {
    val items by cartVm.allItems.collectAsState()
    val total by cartVm.total.collectAsState(initial = 0.0)
    val context = LocalContext.current
    var showSnackbar by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Carrito de Compras", style = MaterialTheme.typography.headlineMedium)

        if (items.isEmpty()) {
            Text("Tu carrito está vacío", style = MaterialTheme.typography.bodyLarge)
        } else {
            items.forEach { item ->
                Text("${item.nombre} x${item.cantidad} = $${"%.0f".format(item.subtotal)}")
            }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("Total: $${"%.0f".format(total)}", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))

            // 🟢 Botón para registrar la compra
            Button(
                onClick = {
                    pedidosVm.registrarPedidoSeguro(total, items) { exito ->
                        if (exito) {
                            snackbarMessage = "Compra registrada con éxito "
                            cartVm.limpiarCarrito()
                            showNotification(
                                context,
                                "Pedido confirmado",
                                "Tu compra por $${"%.0f".format(total)} fue registrada con éxito."
                            )
                        } else {
                            snackbarMessage = "Error al registrar el pedido ❌"
                        }
                        showSnackbar = true
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Comprar")
            }

            //  Botón para vaciar el carrito
            OutlinedButton(
                onClick = { cartVm.limpiarCarrito() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Vaciar Carrito")
            }

            //  Snackbar con mensaje dinámico
            if (showSnackbar) {
                Snackbar(
                    modifier = Modifier.padding(top = 8.dp),
                    action = {
                        TextButton(onClick = { showSnackbar = false }) {
                            Text("OK")
                        }
                    }
                ) {
                    Text(snackbarMessage)
                }
            }
        }
    }
}
