package com.pedidosyapo.repository

import com.pedidosyapo.dao.PedidoDao
import com.pedidosyapo.entity.Pedido
import kotlinx.coroutines.flow.Flow

class PedidoRepository(private val pedidoDao: PedidoDao) {


    fun getAllPedidos(): Flow<List<Pedido>> = pedidoDao.getAllPedidos()


    suspend fun insertPedido(pedido: Pedido): Long {
        return pedidoDao.insertPedido(pedido)
    }


    suspend fun updatePedido(pedido: Pedido) {
        pedidoDao.updatePedido(pedido)
    }


    suspend fun deletePedido(pedido: Pedido) {
        pedidoDao.deletePedido(pedido)
    }


    suspend fun deletePedidoById(id: Long) {
        pedidoDao.deletePedidoById(id)
    }


    suspend fun getPedidoById(id: Long): Pedido? {
        return pedidoDao.getPedidoById(id)
    }


    suspend fun eliminarPedido(id: Long) {
        pedidoDao.deletePedidoById(id)
    }
}
