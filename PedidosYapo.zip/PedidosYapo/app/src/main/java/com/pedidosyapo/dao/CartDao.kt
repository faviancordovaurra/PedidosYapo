package com.pedidosyapo.dao

import androidx.room.*
import com.pedidosyapo.entity.CartItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {

    @Query("SELECT * FROM cart_items")
    fun getAll(): Flow<List<CartItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CartItem)

    @Delete
    suspend fun delete(item: CartItem)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT SUM(subtotal) FROM cart_items")
    fun getTotal(): Flow<Double>

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}
