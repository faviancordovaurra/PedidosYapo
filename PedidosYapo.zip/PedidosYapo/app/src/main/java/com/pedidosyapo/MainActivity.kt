package com.pedidosyapo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.pedidosyapo.Database.AppDatabase
import com.pedidosyapo.repository.PedidosRepository
import com.pedidosyapo.screens.PedidosScreen
import com.pedidosyapo.ui.theme.PedidosYapoTheme
import com.pedidosyapo.viewmodel.PedidosViewModel
import com.pedidosyapo.viewmodel.PedidosViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Base de datos Room
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "pedidosyapo_db"
        ).build()

        // Repositorio
        val repository = PedidosRepository(
            db.productoDao(),
            db.restauranteDao(),
            db.pedidoDao()
        )

        // ViewModel
        val viewModel = ViewModelProvider(
            this,
            PedidosViewModelFactory(repository)
        )[PedidosViewModel::class.java]

        setContent {
            PedidosYapoTheme {
                PedidosScreen(viewModel)
            }
        }
    }
}
