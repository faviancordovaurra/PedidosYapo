package com.pedidosyapo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.room.Room
import com.pedidosyapo.Database.AppDatabase
import com.pedidosyapo.repository.*
import com.pedidosyapo.screens.*
import com.pedidosyapo.ui.theme.PedidosYapoTheme
import com.pedidosyapo.viewmodel.PedidosViewModel
import com.pedidosyapo.viewmodel.ProductoViewModel
import com.pedidosyapo.viewmodel.RestauranteViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // --- Inicialización de la base de datos Room ---
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "pedidosyapo_db"
        ).build()

        // --- Precargar datos iniciales ---
        `DataLoader.kl`.cargarDatosIniciales(this)

        // --- Instancias de Repositorios y ViewModels ---
        val pedidosViewModel = PedidosViewModel(PedidosRepository(db.pedidoDao()))
        val productoViewModel = ProductoViewModel(ProductosRepository(db.productoDao()))
        val restauranteViewModel = RestauranteViewModel(RestaurantesRepository(db.restauranteDao()))

        // --- Cargar interfaz principal ---
        setContent {
            PedidosYapoTheme {
                MainApp(
                    pedidosViewModel = pedidosViewModel,
                    productoViewModel = productoViewModel,
                    restauranteViewModel = restauranteViewModel
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    pedidosViewModel: PedidosViewModel,
    productoViewModel: ProductoViewModel,
    restauranteViewModel: RestauranteViewModel
) {
    var selectedScreen by remember { mutableStateOf("pedidos") }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedScreen == "pedidos",
                    onClick = { selectedScreen = "pedidos" },
                    label = { Text("Pedidos") },
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.ShoppingCart,
                            contentDescription = "Pedidos"
                        )
                    }
                )
                NavigationBarItem(
                    selected = selectedScreen == "productos",
                    onClick = { selectedScreen = "productos" },
                    label = { Text("Productos") },
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Inventory,
                            contentDescription = "Productos"
                        )
                    }
                )
                NavigationBarItem(
                    selected = selectedScreen == "restaurantes",
                    onClick = { selectedScreen = "restaurantes" },
                    label = { Text("Restaurantes") },
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Store,
                            contentDescription = "Restaurantes"
                        )
                    }
                )
            }
        }
    ) { paddingValues ->
        Surface(modifier = Modifier.padding(paddingValues)) {
            when (selectedScreen) {
                "pedidos" -> PedidosScreen(pedidosViewModel)
                "productos" -> ProductosScreen(productoViewModel)
                "restaurantes" -> RestaurantesScreen(restauranteViewModel)
            }
        }
    }
}
