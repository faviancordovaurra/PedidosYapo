package com.pedidosyapo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.pedidosyapo.data.DataLoader
import com.pedidosyapo.database.AppDatabase
import com.pedidosyapo.repository.*
import com.pedidosyapo.ui.MainScreen
import com.pedidosyapo.viewmodel.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //  Inicializa la base de datos local
        val db = AppDatabase.getInstance(applicationContext)

        //  Carga datos iniciales (productos, etc.)
        DataLoader.loadInitialData(this)

        //  Repositorios
        val productoRepo = ProductosRepository(db.productoDao())
        val pedidoRepo = PedidoRepository(db.pedidoDao())
        val detalleRepo = PedidoDetalleRepository(db.pedidoDetalleDao())
        val cartRepo = CartRepository(db.cartDao())

        //  ViewModels
        val productoVm = ProductoViewModelFactory(productoRepo).create(ProductoViewModel::class.java)
        val pedidoVm = PedidosViewModelFactory(pedidoRepo, detalleRepo).create(PedidosViewModel::class.java)
        val cartVm = CartViewModelFactory(cartRepo).create(CartViewModel::class.java)

        // Solicitar permiso de notificaciones (solo Android 13+)
        requestNotificationPermission()

        // Interfaz principal
        setContent {
            MainScreen(
                productoVm = productoVm,
                pedidosVm = pedidoVm,
                cartVm = cartVm
            )
        }
    }

    /**
     *  Solicita el permiso POST_NOTIFICATIONS si es necesario (Android 13+)
     */
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = Manifest.permission.POST_NOTIFICATIONS

            // Si el permiso no está concedido, se pide al usuario
            if (ContextCompat.checkSelfPermission(this, permission)
                != PackageManager.PERMISSION_GRANTED
            ) {
                val launcher = registerForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    if (!isGranted) {
                        println(" Permiso de notificaciones denegado por el usuario")
                    }
                }
                launcher.launch(permission)
            }
        }
    }
}
