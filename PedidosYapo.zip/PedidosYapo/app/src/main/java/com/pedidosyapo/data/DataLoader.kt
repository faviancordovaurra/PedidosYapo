package com.pedidosyapo.data

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.pedidosyapo.database.AppDatabase
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.entity.Restaurante
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object DataLoader {

    fun loadInitialData(context: Context) {
        val db = AppDatabase.getInstance(context)


        CoroutineScope(Dispatchers.IO).launch {
            try {
                val productoDao = db.productoDao()
                val restauranteDao = db.restauranteDao()

                var datosCargados = false


                val productos = productoDao.getAllProductos().firstOrNull() ?: emptyList()
                if (productos.isEmpty()) {
                    productoDao.insert(Producto(nombre = "Hamburguesa", precio = 5500.0))
                    productoDao.insert(Producto(nombre = "Pizza", precio = 8500.0))
                    productoDao.insert(Producto(nombre = "Sushi", precio = 9900.0))
                    Log.d("DataLoader", " Productos iniciales cargados")
                    datosCargados = true
                }


                val restaurantes = restauranteDao.getAllRestaurantes().firstOrNull() ?: emptyList()
                if (restaurantes.isEmpty()) {
                    restauranteDao.insert(Restaurante(nombre = "La Pica", direccion = "Av. Central 123", telefono = "987654321"))
                    restauranteDao.insert(Restaurante(nombre = "Donde Juan", direccion = "Calle Falsa 456", telefono = "912345678"))
                    Log.d("DataLoader", " Restaurantes iniciales cargados")
                    datosCargados = true
                }


                if (datosCargados) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Datos iniciales cargados ", Toast.LENGTH_SHORT).show()
                    }
                }

            } catch (e: Exception) {
                Log.e("DataLoader", " Error cargando datos iniciales", e)
            }
        }
    }
}
