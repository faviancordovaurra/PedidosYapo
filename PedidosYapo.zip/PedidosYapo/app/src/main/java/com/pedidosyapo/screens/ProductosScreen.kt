package com.pedidosyapo.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.entity.CartItem
import com.pedidosyapo.viewmodel.CartViewModel
import com.pedidosyapo.viewmodel.ProductoViewModel
import kotlinx.coroutines.launch

@Composable
fun ProductosScreen(viewModel: ProductoViewModel, cartVm: CartViewModel) {
    val productos: List<Producto> by viewModel.productos.collectAsState(initial = emptyList())
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text("Menú de Comidas ", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(16.dp))

            if (productos.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No hay productos disponibles ")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(productos) { producto ->
                        ProductoCard(
                            producto = producto,
                            onAgregar = {

                                val item = CartItem(
                                    menuItemId = producto.id,
                                    nombre = producto.nombre,
                                    precio = producto.precio,
                                    cantidad = 1,
                                    subtotal = producto.precio
                                )
                                cartVm.agregarAlCarrito(item)
                                scope.launch {
                                    snackbarHostState.showSnackbar(
                                        "${producto.nombre} agregado al carrito "
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProductoCard(producto: Producto, onAgregar: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(producto.nombre, style = MaterialTheme.typography.titleMedium)
            Text("$${producto.precio}", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Cantidad: 1")
                IconButton(onClick = onAgregar) {
                    Icon(Icons.Default.AddShoppingCart, contentDescription = "Agregar al carrito")
                }
            }
        }
    }
}
