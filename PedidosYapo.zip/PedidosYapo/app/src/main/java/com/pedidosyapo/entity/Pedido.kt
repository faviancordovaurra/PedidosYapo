package com.pedidosyapo.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pedido")
data class Pedido(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cliente: String,
    val direccion: String,
    val fecha: String,
    val estado: String = "Pendiente",
    val total: Double
)
