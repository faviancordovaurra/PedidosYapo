package com.pedidosyapo.dao

import androidx.room.*
import com.pedidosyapo.entity.Pedido
import kotlinx.coroutines.flow.Flow

@Dao
interface PedidoDao {

    @Query("SELECT * FROM pedido ORDER BY id DESC")
    fun getAllPedidos(): Flow<List<Pedido>>

    @Query("SELECT * FROM pedido WHERE id = :id")
    suspend fun getPedidoById(id: Long): Pedido?

    // 🟢 Devuelve el ID generado del pedido insertado
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPedido(pedido: Pedido): Long

    @Update
    suspend fun updatePedido(pedido: Pedido)

    @Delete
    suspend fun deletePedido(pedido: Pedido)

    @Query("DELETE FROM pedido WHERE id = :id")
    suspend fun deletePedidoById(id: Long)
}
