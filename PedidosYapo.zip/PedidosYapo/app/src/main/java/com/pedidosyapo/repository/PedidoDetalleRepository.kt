package com.pedidosyapo.repository

import com.pedidosyapo.dao.PedidoDetalleDao
import com.pedidosyapo.entity.PedidoDetalle

class PedidoDetalleRepository(private val dao: PedidoDetalleDao) {
    suspend fun insertarDetalles(detalles: List<PedidoDetalle>) {
        dao.insertarDetalles(detalles)
    }
    suspend fun obtenerDetalles(pedidoId: Long): List<PedidoDetalle> {
        return dao.obtenerDetallesPorPedido(pedidoId)
    }
    suspend fun eliminarPorPedidoId(pedidoId: Long) {
    }
}
