package com.pedidosyapo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.pedidosyapo.repository.PedidoRepository
import com.pedidosyapo.repository.PedidoDetalleRepository

class PedidosViewModelFactory(
    private val pedidoRepo: PedidoRepository,
    private val detalleRepo: PedidoDetalleRepository
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PedidosViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PedidosViewModel(pedidoRepo, detalleRepo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
