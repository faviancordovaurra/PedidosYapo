package com.pedidosyapo.repository

import com.pedidosyapo.dao.CartDao
import com.pedidosyapo.entity.CartItem
import kotlinx.coroutines.flow.Flow

class CartRepository(private val cartDao: CartDao) {

    // Obtener todos los ítems del carrito
    fun getAllItems(): Flow<List<CartItem>> = cartDao.getAll()

    // Insertar o actualizar un ítem
    suspend fun insertItem(item: CartItem) = cartDao.insert(item)

    // Eliminar un ítem específico
    suspend fun deleteItem(item: CartItem) = cartDao.delete(item)

    // Eliminar un ítem por ID
    suspend fun deleteItemById(id: Long) = cartDao.deleteById(id)

    // Obtener el total del carrito
    fun getTotal(): Flow<Double> = cartDao.getTotal()

    // Vaciar completamente el carrito
    suspend fun clearCart() = cartDao.clearCart()
}
