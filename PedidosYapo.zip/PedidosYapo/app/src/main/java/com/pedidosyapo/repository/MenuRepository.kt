package com.pedidosyapo.repository

import com.pedidosyapo.dao.MenuItemDao
import com.pedidosyapo.entity.MenuItem

class MenuRepository(private val menuDao: MenuItemDao) {
    suspend fun getByRestaurante(restId: Long): List<MenuItem> =
        menuDao.getByRestaurante(restId)
}
