package com.pedidosyapo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.repository.RestaurantesRepository
import com.pedidosyapo.entity.Restaurante
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RestauranteViewModel(
    private val repository: RestaurantesRepository
) : ViewModel() {

    val restaurantes: StateFlow<List<Restaurante>> =
        repository.restaurantes.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    fun agregar(nombre: String, direccion: String, telefono: String) {
        viewModelScope.launch {
            try {
                repository.agregar(nombre, direccion, telefono)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    fun eliminar(id: Long) {
        viewModelScope.launch {
            try {
                repository.eliminar(id)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
