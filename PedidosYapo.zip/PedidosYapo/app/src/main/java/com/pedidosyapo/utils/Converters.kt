package com.pedidosyapo.utils

import androidx.annotation.RequiresApi
import androidx.room.TypeConverter
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Date

class Converters {

    // -------------------------------
    // Soporte para java.util.Date
    // -------------------------------
    @TypeConverter
    fun fromLongToDate(value: Long?): Date? =
        value?.let { Date(it) }

    @TypeConverter
    fun fromDateToLong(date: Date?): Long? =
        date?.time

    // -------------------------------
    // Soporte para java.time.LocalDate
    // -------------------------------
    @TypeConverter
    fun fromStringToLocalDate(value: String?): LocalDate? =
        value?.let { LocalDate.parse(it) }

    @TypeConverter
    fun fromLocalDateToString(date: LocalDate?): String? =
        date?.toString()

    // -------------------------------
    // Soporte para java.time.LocalDateTime
    // -------------------------------
    @RequiresApi(26)
    @TypeConverter
    fun fromTimestamp(value: Long?): LocalDateTime? =
        value?.let {
            LocalDateTime.ofInstant(
                Instant.ofEpochMilli(it),
                ZoneId.systemDefault()
            )
        }

    @RequiresApi(26)
    @TypeConverter
    fun dateTimeToTimestamp(dateTime: LocalDateTime?): Long? =
        dateTime?.atZone(ZoneId.systemDefault())
            ?.toInstant()
            ?.toEpochMilli()
}
