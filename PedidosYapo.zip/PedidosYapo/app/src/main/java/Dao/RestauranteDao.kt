package com.pedidosyapo.Dao

import androidx.room.*
import com.pedidosyapo.entity.Restaurante
import kotlinx.coroutines.flow.Flow

@Dao
interface RestauranteDao {
    @Query("SELECT * FROM restaurantes")
    fun obtenerRestaurantes(): Flow<List<Restaurante>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarRestaurante(restaurante: Restaurante)

    @Delete
    suspend fun eliminarRestaurante(restaurante: Restaurante)
}
