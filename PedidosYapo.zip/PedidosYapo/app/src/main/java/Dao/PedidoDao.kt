package com.pedidosyapo.Dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.pedidosyapo.entity.Pedido

@Dao
interface PedidoDao {
    @Query("SELECT * FROM pedido")
    suspend fun getAll(): List<Pedido>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pedido: Pedido)

    @Delete
    suspend fun delete(pedido: Pedido)
}
