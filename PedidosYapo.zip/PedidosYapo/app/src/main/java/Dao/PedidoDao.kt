package com.pedidosyapo.Dao

import androidx.room.*
import com.pedidosyapo.entity.Pedido
import kotlinx.coroutines.flow.Flow

@Dao
interface PedidoDao {
    @Query("SELECT * FROM pedidos ORDER BY fecha DESC")
    fun obtenerPedidos(): Flow<List<Pedido>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarPedido(pedido: Pedido)

    @Delete
    suspend fun eliminarPedido(pedido: Pedido)
}
