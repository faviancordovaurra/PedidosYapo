package com.pedidosyapo.Dao

import androidx.room.*
import com.pedidosyapo.entity.Producto
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductoDao {
    @Query("SELECT * FROM productos")
    fun obtenerProductos(): Flow<List<Producto>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarProducto(producto: Producto)

    @Delete
    suspend fun eliminarProducto(producto: Producto)
}
