package com.pedidosyapo.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Pedido")
data class Pedido(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fecha: String,
    val total: Double
)
