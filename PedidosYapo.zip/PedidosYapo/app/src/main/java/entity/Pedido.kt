package com.pedidosyapo.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "pedidos")
data class Pedido(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val idProducto: Int,
    val idRestaurante: Int,
    val cantidad: Int,
    val fecha: Date = Date()
)
