package com.pedidosyapo.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.ShoppingCart
import com.pedidosyapo.screens.PedidosScreen
import com.pedidosyapo.screens.ProductosScreen
import com.pedidosyapo.screens.RestaurantesScreen
import com.pedidosyapo.viewmodel.*

@Composable
fun MainScreen(
    pedidosViewModel: PedidosViewModel,
    productoViewModel: ProductoViewModel,
    restauranteViewModel: RestauranteViewModel
) {
    var selectedTab by remember { mutableStateOf("pedidos") }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == "pedidos",
                    onClick = { selectedTab = "pedidos" },
                    label = { Text("Pedidos") },
                    icon = { Icon(Icons.Default.ShoppingCart, contentDescription = null) }
                )
                NavigationBarItem(
                    selected = selectedTab == "productos",
                    onClick = { selectedTab = "productos" },
                    label = { Text("Productos") },
                    icon = { Icon(Icons.Default.List, contentDescription = null) }
                )
                NavigationBarItem(
                    selected = selectedTab == "restaurantes",
                    onClick = { selectedTab = "restaurantes" },
                    label = { Text("Restaurantes") },
                    icon = { Icon(Icons.Default.Restaurant, contentDescription = null) }
                )
            }
        }
    ) { innerPadding ->
        when (selectedTab) {
            "pedidos" -> PedidosScreen(pedidosViewModel, Modifier.padding(innerPadding))
            "productos" -> ProductosScreen(productoViewModel, Modifier.padding(innerPadding))
            "restaurantes" -> RestaurantesScreen(restauranteViewModel, Modifier.padding(innerPadding))
        }
    }
}
