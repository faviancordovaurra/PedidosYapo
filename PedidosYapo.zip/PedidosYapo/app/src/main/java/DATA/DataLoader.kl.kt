package com.pedidosyapo.Database

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.entity.Restaurante
import com.pedidosyapo.entity.Pedido

object `DataLoader.kl` {

    fun cargarDatosIniciales(context: Context) {
        val db = AppDatabase.getDatabase(context)

        // Ejecutar la carga en un hilo de corrutina
        kotlinx.coroutines.GlobalScope.launch(Dispatchers.IO) {

            // --- Restaurantes ---
            val restaurantes = listOf(
                Restaurante(nombre = "La Picada de Juan", direccion = "Av. Central 123", telefono = "987654321"),
                Restaurante(nombre = "Sushi Go", direccion = "Calle Oriente 45", telefono = "998877665"),
                Restaurante(nombre = "Pizza Mundo", direccion = "Los Olivos 890", telefono = "934567890")
            )

            // --- Productos ---
            val productos = listOf(
                Producto(nombre = "Pizza Napolitana", precio = 8990.0),
                Producto(nombre = "Roll California", precio = 7490.0),
                Producto(nombre = "Empanada de Pino", precio = 1200.0)
            )

            // --- Pedidos ---
            val pedidos = listOf(
                Pedido(fecha = "2025-10-28", total = 18500.0),
                Pedido(fecha = "2025-10-27", total = 8990.0)
            )

            // Inserción con DAOs
            db.restauranteDao().insertAll(restaurantes)
            db.productoDao().insertAll(productos)
            db.pedidoDao().insertAll(pedidos)

            // Confirmación en Logcat (solo visible al ejecutar la app)
            withContext(Dispatchers.Main) {
                println("✅ Datos iniciales cargados correctamente en la base de datos Room.")
            }
        }
    }
}
