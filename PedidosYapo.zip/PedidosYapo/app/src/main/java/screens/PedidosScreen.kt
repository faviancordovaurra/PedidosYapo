package com.pedidosyapo.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.viewmodel.PedidosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PedidosScreen(viewModel: PedidosViewModel) {
    val pedidos by viewModel.pedidos.collectAsState()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        "Pedidos Yapo",
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    // Pedido de ejemplo (se puede reemplazar luego por formulario)
                    viewModel.agregarPedido(Pedido(idProducto = 1, idRestaurante = 1, cantidad = 1))
                },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Agregar Pedido")
            }
        }
    ) { padding ->
        if (pedidos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Aún no hay pedidos registrados",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                items(pedidos) { pedido ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Pedido #${pedido.id}", style = MaterialTheme.typography.titleMedium)
                            Text("Producto ID: ${pedido.idProducto}")
                            Text("Restaurante ID: ${pedido.idRestaurante}")
                            Text("Cantidad: ${pedido.cantidad}")
                            Text("Fecha: ${pedido.fecha}")
                        }
                    }
                }
            }
        }
    }
}
