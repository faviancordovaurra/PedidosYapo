package com.pedidosyapo.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.viewmodel.PedidosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PedidosScreen(viewModel: PedidosViewModel) {
    var fecha by remember { mutableStateOf("") }
    var total by remember { mutableStateOf("") }

    val pedidos by viewModel.pedidos.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // --- Título ---
        Text(
            text = "Gestión de Pedidos",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(8.dp))

        // --- Campo Fecha ---
        OutlinedTextField(
            value = fecha,
            onValueChange = { fecha = it },
            label = { Text("Fecha del pedido (YYYY-MM-DD)") },
            isError = fecha.isBlank(),
            supportingText = {
                if (fecha.isBlank()) Text("Campo obligatorio")
            },
            modifier = Modifier.fillMaxWidth()
        )

        // --- Campo Total ---
        OutlinedTextField(
            value = total,
            onValueChange = { total = it },
            label = { Text("Total (CLP)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            isError = total.isBlank(),
            supportingText = {
                if (total.isBlank()) Text("Campo obligatorio")
            },
            modifier = Modifier.fillMaxWidth()
        )

        // --- Botón agregar ---
        Button(
            onClick = {
                if (fecha.isNotBlank() && total.isNotBlank()) {
                    viewModel.agregar(fecha, total.toDoubleOrNull() ?: 0.0)
                    fecha = ""
                    total = ""
                }
            },
            enabled = fecha.isNotBlank() && total.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        ) {
            Text("Agregar Pedido")
        }

        Spacer(Modifier.height(16.dp))

        // --- Lista de pedidos ---
        AnimatedVisibility(visible = pedidos.isNotEmpty()) {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(pedidos) { pedido ->
                    PedidoItem(
                        pedido = pedido,
                        onDelete = { viewModel.eliminar(it) }
                    )
                }
            }
        }

        // --- Mensaje cuando no hay pedidos ---
        AnimatedVisibility(visible = pedidos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 50.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No hay pedidos registrados aún",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun PedidoItem(pedido: Pedido, onDelete: (Pedido) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Fecha: ${pedido.fecha}")
                Text("Total: $${pedido.total}")
            }
            IconButton(onClick = { onDelete(pedido) }) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Eliminar Pedido",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
