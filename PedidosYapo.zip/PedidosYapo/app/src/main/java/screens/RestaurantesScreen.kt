package com.pedidosyapo.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.pedidosyapo.entity.Restaurante
import com.pedidosyapo.viewmodel.RestauranteViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RestaurantesScreen(viewModel: RestauranteViewModel) {
    var nombre by remember { mutableStateOf("") }
    var direccion by remember { mutableStateOf("") }
    var telefono by remember { mutableStateOf("") }

    val restaurantes by viewModel.restaurantes.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        // --- Título ---
        Text(
            text = "Gestión de Restaurantes",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(8.dp))

        // --- Campo Nombre ---
        OutlinedTextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Nombre del restaurante") },
            isError = nombre.isBlank(),
            supportingText = {
                if (nombre.isBlank()) Text("Campo obligatorio")
            },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
        )

        // --- Campo Dirección ---
        OutlinedTextField(
            value = direccion,
            onValueChange = { direccion = it },
            label = { Text("Dirección del restaurante") },
            isError = direccion.isBlank(),
            supportingText = {
                if (direccion.isBlank()) Text("Campo obligatorio")
            },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
        )

        // --- Campo Teléfono ---
        OutlinedTextField(
            value = telefono,
            onValueChange = { telefono = it },
            label = { Text("Teléfono") },
            isError = telefono.isBlank(),
            supportingText = {
                if (telefono.isBlank()) Text("Campo obligatorio")
            },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )

        // --- Botón agregar ---
        Button(
            onClick = {
                if (nombre.isNotBlank() && direccion.isNotBlank() && telefono.isNotBlank()) {
                    viewModel.agregar(nombre, direccion, telefono)
                    nombre = ""
                    direccion = ""
                    telefono = ""
                }
            },
            enabled = nombre.isNotBlank() && direccion.isNotBlank() && telefono.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        ) {
            Text("Agregar Restaurante")
        }

        Spacer(Modifier.height(16.dp))

        // --- Lista de restaurantes ---
        AnimatedVisibility(visible = restaurantes.isNotEmpty()) {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(restaurantes) { restaurante ->
                    RestauranteItem(
                        restaurante = restaurante,
                        onDelete = { viewModel.eliminar(it) }
                    )
                }
            }
        }

        // --- Mensaje cuando no hay restaurantes ---
        AnimatedVisibility(visible = restaurantes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 50.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No hay restaurantes registrados aún",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun RestauranteItem(restaurante: Restaurante, onDelete: (Restaurante) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Nombre: ${restaurante.nombre}")
                Text("Dirección: ${restaurante.direccion}")
                Text("Teléfono: ${restaurante.telefono}")
            }
            IconButton(onClick = { onDelete(restaurante) }) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Eliminar Restaurante",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
