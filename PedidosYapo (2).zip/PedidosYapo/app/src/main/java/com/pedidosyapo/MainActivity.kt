package com.pedidosyapo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pedidosyapo.database.AppDatabase
import com.pedidosyapo.repository.CheckoutRepository
import com.pedidosyapo.repository.ProductosRepository
import com.pedidosyapo.repository.RestaurantesRepository
import com.pedidosyapo.viewmodel.PedidosViewModel
import com.pedidosyapo.viewmodel.PedidosViewModelFactory
import com.pedidosyapo.viewmodel.ProductoViewModel
import com.pedidosyapo.viewmodel.ProductoViewModelFactory
import com.pedidosyapo.viewmodel.RestauranteViewModel
import com.pedidosyapo.viewmodel.RestauranteViewModelFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // BD (singleton)
        val database = AppDatabase.getInstance(applicationContext)

        // Precarga (opcional)
        lifecycleScope.launch(context = Dispatchers.IO) {
            // DataLoader(db = database).preloadIfEmpty()  // si tienes DataLoader
        }

        // Repositorios
        val checkoutRepository = CheckoutRepository(db = database)
        val productosRepository = ProductosRepository(dao = database.productoDao())
        val restaurantesRepository = RestaurantesRepository(dao = database.restauranteDao())

        // Factories
        val pedidosFactory = PedidosViewModelFactory(checkoutRepository)
        val productoFactory = ProductoViewModelFactory(productosRepository)
        val restauranteFactory = RestauranteViewModelFactory(restaurantesRepository)

        setContent {
            // Tipos explícitos:
            val pedidosViewModel: PedidosViewModel =
                viewModel(factory = pedidosFactory)

            val productoViewModel: ProductoViewModel =
                viewModel(factory = productoFactory)

            val restauranteViewModel: RestauranteViewModel =
                viewModel(factory = restauranteFactory)

            MainScreen(
                pedidosViewModel = pedidosViewModel,
                productoViewModel = productoViewModel,
                restauranteViewModel = restauranteViewModel
            )
        }
    }
}

