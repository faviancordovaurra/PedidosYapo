package com.pedidosyapo.data

import com.pedidosyapo.database.AppDatabase
import com.pedidosyapo.entity.MenuItem
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.entity.Restaurante
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DataLoader(private val db: AppDatabase) {

    /**
     * Precarga data solo si las tablas están vacías.
     * Llamar desde un contexto suspend (por ej. dentro de un CoroutineScope).
     */
    suspend fun preloadIfEmpty() = withContext(Dispatchers.IO) {
        // --- Restaurantes ---
        val restExistentes: List<Restaurante> = db.restauranteDao().getAll()
        if (restExistentes.isEmpty()) {
            val r1 = Restaurante(nombre = "Pizza Flash", direccion = "Centro 123", telefono = "2222222")
            val r2 = Restaurante(nombre = "Sushi GO",   direccion = "Norte 456",  telefono = "2333333")
            db.restauranteDao().insert(r1)
            db.restauranteDao().insert(r2)
        }

        // Releer para obtener IDs
        val restaurantes: List<Restaurante> = db.restauranteDao().getAll()
        val restId: Long = restaurantes.firstOrNull()?.id ?: return@withContext  // si no hay, salir

        // --- Productos (demo) ---
        val productos: List<Producto> = db.productoDao().getAll()
        if (productos.isEmpty()) {
            db.productoDao().insert(Producto(nombre = "Bebida lata", precio = 1200.0))
            db.productoDao().insert(Producto(nombre = "Agua 500ml",  precio = 900.0))
        }

        // --- Menú por restaurante ---
        val menuActual: List<MenuItem> = db.menuItemDao().getByRestaurante(restId)
        if (menuActual.isEmpty()) {
            val items = listOf(
                MenuItem(restauranteId = restId, nombre = "Pizza M",   descripcion = "Mozzarella", precio = 6990.0),
                MenuItem(restauranteId = restId, nombre = "Pizza XL",  descripcion = "Pepperoni",  precio = 9990.0),
                MenuItem(restauranteId = restId, nombre = "Bebida 1.5", descripcion = "Cola",     precio = 1990.0)
            )
            db.menuItemDao().insertAll(items)
        }
    }
}
