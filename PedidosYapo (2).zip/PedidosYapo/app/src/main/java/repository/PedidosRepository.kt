package com.pedidosyapo.repository

import com.pedidosyapo.dao.PedidoDao
import com.pedidosyapo.entity.Pedido

class PedidosRepository(private val pedidoDao: PedidoDao) {

    suspend fun getAllPedidos(): List<Pedido> = pedidoDao.getAll()
    suspend fun insertPedido(pedido: Pedido) = pedidoDao.insert(pedido)
    suspend fun deletePedido(pedido: Pedido) = pedidoDao.delete(pedido)
}
