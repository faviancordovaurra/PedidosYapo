package com.pedidosyapo.repository

import com.pedidosyapo.database.dao.ProductoDao
import com.pedidosyapo.entity.Producto
import kotlinx.coroutines.flow.Flow

class ProductosRepository(
    private val dao: ProductoDao
) {
    fun getAll(): Flow<List<Producto>> = dao.getAll()

    suspend fun insert(producto: Producto) = dao.insert(producto)

    suspend fun delete(producto: Producto) = dao.delete(producto)
}
