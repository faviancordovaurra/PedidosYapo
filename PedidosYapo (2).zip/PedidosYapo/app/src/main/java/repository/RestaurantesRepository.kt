package com.pedidosyapo.repository

import com.pedidosyapo.dao.RestauranteDao
import com.pedidosyapo.entity.Restaurante

class RestaurantesRepository(private val restauranteDao: RestauranteDao) {

    suspend fun getAllRestaurantes(): List<Restaurante> = restauranteDao.getAll()
    suspend fun insertRestaurante(restaurante: Restaurante) = restauranteDao.insert(restaurante)
    suspend fun deleteRestaurante(restaurante: Restaurante) = restauranteDao.delete(restaurante)
}
