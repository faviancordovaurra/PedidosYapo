package com.pedidosyapo.repository

import com.pedidosyapo.database.AppDatabase
import com.pedidosyapo.entity.CartItem
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.entity.PedidoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class CheckoutRepository(private val db: AppDatabase) {
    suspend fun realizarPedido(restId: Long, dirEntrega: String): Long = withContext(Dispatchers.IO) {
        val fecha = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        // 1) Items del carrito (lectura inmediata)
        val cartItems: List<CartItem> = db.cartItemDao().getAll()

        // 2) Mapa precio por menuItemId (usando MenuItemDao)
        //    getByRestaurante devuelve List<MenuItem>, no Flow -> no usar .first()
        val menuItems = db.menuItemDao().getByRestaurante(restId)
        val precioPorMenuItemId: Map<Long, Double> = menuItems.associate { mi ->
            mi.id to (mi.precio ?: 0.0)
        }

        // 3) Total del pedido
        val total: Double = cartItems.sumOf { ci ->
            (precioPorMenuItemId[ci.menuItemId] ?: 0.0) * ci.cantidad.toDouble()
        }

        // 4) Insert Pedido (Room devuelve el id generado)
        val pedidoId: Long = db.pedidoDao().insert(
            Pedido(
                id = 0,
                restauranteId = restId,
                fecha = fecha,
                total = total,
                direccionEntrega = dirEntrega,
                estado = "PENDIENTE"
            )
        )

        // 5) Insert de los items del pedido
        val items: List<PedidoItem> = cartItems.map { ci ->
            PedidoItem(
                id = 0,
                pedidoId = pedidoId,
                menuItemId = ci.menuItemId,
                cantidad = ci.cantidad,
                precioUnit = precioPorMenuItemId[ci.menuItemId] ?: 0.0
            )
        }
        db.pedidoItemDao().insertAll(items)

        // 6) Vaciar carrito
        db.cartItemDao().clear()

        // 7) Retornar id del pedido
        pedidoId
    }
}
