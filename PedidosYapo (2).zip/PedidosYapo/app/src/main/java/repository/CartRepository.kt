package com.pedidosyapo.repository

import com.pedidosyapo.database.dao.CartItemDao
import com.pedidosyapo.entity.CartItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CartRepository(
    private val cartItemDao: CartItemDao
) {
    /** Devuelve el carrito como Flow (se actualiza en tiempo real). */
    fun getAll(): Flow<List<CartItem>> = cartItemDao.getAll()

    /**
     * Total del carrito como Flow.
     * Si tu DAO no tiene el precio, esto suma cantidades (placeholder).
     * Cambia la lógica si tienes precio por ítem (ver nota al final).
     */
    fun total(): Flow<Double> = cartItemDao
        .getAll()
        .map { items ->
            // Placeholder: si no tienes precio, al menos no rompe compilación
            // Reemplaza por cantidad * precio cuando tengas precio disponible
            items.sumOf { it.cantidad.toDouble() }
        }

    suspend fun deleteById(id: Long) = cartItemDao.deleteById(id)
}
