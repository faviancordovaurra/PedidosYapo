// app/src/main/java/com/pedidosyapo/database/AppDatabase.kt
package com.pedidosyapo.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

// DAOs (en el paquete com.pedidosyapo.dao)
import com.pedidosyapo.dao.ProductoDao
import com.pedidosyapo.dao.MenuItemDao
import com.pedidosyapo.dao.PedidoDao
import com.pedidosyapo.dao.PedidoItemDao
import com.pedidosyapo.dao.CartItemDao
import com.pedidosyapo.dao.RestauranteDao


// Entidades (en el paquete com.pedidosyapo.entity)
import com.pedidosyapo.entity.CartItem
import com.pedidosyapo.entity.MenuItem
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.entity.PedidoItem
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.entity.Restaurante

// Converters (si los usas)
import com.pedidosyapo.utils.Converters

@Database(
    entities = [
        Producto::class,
        Restaurante::class,
        Pedido::class,
        PedidoItem::class,
        MenuItem::class,
        CartItem::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    // Exponer todos los DAOs que tienes
    abstract fun productoDao(): ProductoDao
    abstract fun restauranteDao(): RestauranteDao
    abstract fun pedidoDao(): PedidoDao
    abstract fun pedidoItemDao(): PedidoItemDao
    abstract fun menuItemDao(): MenuItemDao
    abstract fun cartItemDao(): CartItemDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pedidosyapo.db"
                )
                    // .fallbackToDestructiveMigration() // opcional en desarrollo
                    .build().also { INSTANCE = it }
            }
    }
}
