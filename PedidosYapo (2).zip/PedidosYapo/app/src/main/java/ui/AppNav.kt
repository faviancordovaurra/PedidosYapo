package ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

// Screens
import screens.CartScreen
import screens.PedidosScreen
import screens.ProductosScreen
import screens.RestaurantesScreen

// DB / Repo
import com.pedidosyapo.database.AppDatabase
import com.pedidosyapo.repository.PedidosRepository

// ViewModel
import viewmodel.PedidosViewModel
import viewmodel.PedidosViewModelFactory

// Rutas simples para las pantallas
sealed class Dest(val route: String) {
    object Restaurantes : Dest("restaurantes")
    object Productos    : Dest("productos")
    object Pedidos      : Dest("pedidos")
    object Carrito      : Dest("carrito")
}

@Composable
fun AppNav() {
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = Dest.Restaurantes.route) {

        composable(Dest.Restaurantes.route) {
            RestaurantesScreen(
                onGoProductos = { nav.navigate(Dest.Productos.route) },
                onGoCarrito   = { nav.navigate(Dest.Carrito.route) }
            )
        }

        composable(Dest.Productos.route) {
            ProductosScreen(
                onGoPedidos = { nav.navigate(Dest.Pedidos.route) },
                onGoCarrito = { nav.navigate(Dest.Carrito.route) }
            )
        }

        composable(Dest.Pedidos.route) {
            // Crear VM con Factory y pasarlo a la pantalla
            val context = LocalContext.current
            val db = AppDatabase.getInstance(context)
            val repo = PedidosRepository(db.pedidoDao())

            val pedidosVm: PedidosViewModel = viewModel(
                factory = PedidosViewModelFactory(repo)
            )

            PedidosScreen(pedidosVm = pedidosVm)
        }

        composable(Dest.Carrito.route) {
            CartScreen(onBack = { nav.popBackStack() })
        }
    }
}
