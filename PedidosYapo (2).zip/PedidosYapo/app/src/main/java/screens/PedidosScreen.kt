package screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.viewmodel.PedidosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PedidosScreen(
    pedidosVm: PedidosViewModel
) {
    // Observa la lista desde StateFlow del VM
    val pedidos: List<Pedido> = pedidosVm.pedidos.collectAsState(initial = emptyList()).value

    var restIdTxt by remember { mutableStateOf("") }
    var direccion by remember { mutableStateOf("") }
    var totalTxt  by remember { mutableStateOf("") }
    var fecha     by remember { mutableStateOf("") }
    var estado    by remember { mutableStateOf("PENDIENTE") }

    Scaffold(topBar = { TopAppBar(title = { Text("Pedidos") }) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = restIdTxt,
                onValueChange = { restIdTxt = it },
                label = { Text("Restaurante ID (Long)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = direccion,
                onValueChange = { direccion = it },
                label = { Text("Dirección de entrega") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = totalTxt,
                onValueChange = { totalTxt = it },
                label = { Text("Total (Double)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = fecha,
                onValueChange = { fecha = it },
                label = { Text("Fecha (yyyy-MM-dd)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = estado,
                onValueChange = { estado = it },
                label = { Text("Estado") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            val restOk  = restIdTxt.toLongOrNull()
            val totalOk = totalTxt.toDoubleOrNull()
            val puedeCrear = restOk != null &&
                    totalOk != null &&
                    direccion.isNotBlank() &&
                    fecha.isNotBlank()

            Button(
                onClick = {
                    pedidosVm.agregar(
                        restauranteId   = restOk!!,
                        fecha           = fecha,
                        total           = totalOk!!,
                        direccionEntrega= direccion,
                        estado          = estado.ifBlank { "PENDIENTE" }
                    )
                    // limpiar form
                    restIdTxt = ""
                    direccion = ""
                    totalTxt  = ""
                    fecha     = ""
                    estado    = "PENDIENTE"
                },
                enabled = puedeCrear
            ) { Text("Crear pedido") }

            HorizontalDivider()

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(pedidos, key = { it.id }) { p ->
                    ListItem(
                        headlineContent = { Text("Pedido #${p.id}") },
                        supportingContent = {
                            Text(
                                "RestId=${p.restauranteId} • " +
                                        "Total=$${"%.0f".format(p.total)} • " +
                                        "Fecha=${p.fecha} • " +
                                        "Estado=${p.estado} • " +
                                        "Dir=${p.direccionEntrega}"
                            )
                        },
                        trailingContent = {
                            IconButton(onClick = { pedidosVm.eliminar(p) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Eliminar")
                            }
                        }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
