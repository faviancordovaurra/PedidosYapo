package screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.viewmodel.ProductoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductosScreen(
    viewModel: ProductoViewModel,
    modifier: Modifier = Modifier
) {
    var nombre by remember { mutableStateOf("") }
    var precio by remember { mutableStateOf("") }

    // Observa los productos en tiempo real (StateFlow<List<Producto>>)
    val productos by viewModel.productos.collectAsState(initial = emptyList())

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Gestión de Productos",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Nombre del producto") },
            isError = nombre.isBlank(),
            supportingText = { if (nombre.isBlank()) Text("Campo obligatorio") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = precio,
            onValueChange = { precio = it },
            label = { Text("Precio (CLP)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            isError = precio.isBlank(),
            supportingText = { if (precio.isBlank()) Text("Campo obligatorio") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                if (nombre.isNotBlank() && precio.isNotBlank()) {
                    viewModel.agregar(nombre, precio.toDoubleOrNull() ?: 0.0)
                    nombre = ""
                    precio = ""
                }
            },
            enabled = nombre.isNotBlank() && precio.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        ) { Text("Agregar Producto") }

        Spacer(Modifier.height(16.dp))

        AnimatedVisibility(visible = productos.isNotEmpty()) {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    items = productos,
                    key = { it.id } // usa el ID autogenerado
                ) { producto ->
                    ProductoItem(
                        producto = producto,
                        onDelete = { viewModel.eliminar(it) }
                    )
                }
            }
        }

        AnimatedVisibility(visible = productos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 50.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No hay productos registrados aún",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun ProductoItem(producto: Producto, onDelete: (Producto) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Nombre: ${producto.nombre}")
                Text("Precio: $${"%.0f".format(producto.precio)}")
            }
            IconButton(onClick = { onDelete(producto) }) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Eliminar Producto",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

