package com.pedidosyapo.dao


import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.pedidosyapo.entity.Producto
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductoDao {

    @Query("SELECT * FROM producto ORDER BY id DESC")
    fun getAll(): Flow<List<Producto>>

    @Insert
    suspend fun insert(producto: Producto)

    @Delete
    suspend fun delete(producto: Producto)
}
