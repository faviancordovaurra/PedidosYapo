package com.pedidosyapo.dao

import androidx.room.*
import com.pedidosyapo.entity.Restaurante

@Dao
interface RestauranteDao {
    @Query("SELECT * FROM restaurante")
    suspend fun getAll(): List<Restaurante>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(restaurante: Restaurante)

    @Delete
    suspend fun delete(restaurante: Restaurante)
}
