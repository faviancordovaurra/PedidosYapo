package com.pedidosyapo.dao

import androidx.room.*
import com.pedidosyapo.entity.Pedido

@Dao
interface PedidoDao {
    @Query("SELECT * FROM pedido")
    suspend fun getAll(): List<Pedido>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pedido: Pedido): Long

    @Delete
    suspend fun delete(pedido: Pedido)
}
