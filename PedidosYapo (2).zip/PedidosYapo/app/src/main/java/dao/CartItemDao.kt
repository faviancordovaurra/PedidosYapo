package com.pedidosyapo.dao

import androidx.room.Dao
import androidx.room.Query
import com.pedidosyapo.entity.CartItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CartItemDao {
    @Query("SELECT * FROM CartItem ORDER BY id DESC")
    fun getAll(): Flow<List<CartItem>>

    @Query("DELETE FROM CartItem WHERE id = :id")
    suspend fun deleteById(id: Long)
}

