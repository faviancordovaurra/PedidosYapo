package com.pedidosyapo.entity



import androidx.room.*

@Entity(tableName = "menuitem")
data class MenuItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val restauranteId: Long,
    val nombre: String,
    val precio: Double
)
