package com.pedidosyapo.entity



import androidx.room.Entity
import androidx.room.PrimaryKey

// Restaurante.kt
@Entity(tableName = "restaurante")
data class Restaurante(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val direccion: String
)
