package com.pedidosyapo.entity



import androidx.room.*

@Entity(
    foreignKeys = [
        ForeignKey(
            entity = Pedido::class, parentColumns = ["id"],
            childColumns = ["pedidoId"], onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = MenuItem::class, parentColumns = ["id"],
            childColumns = ["menuItemId"], onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("pedidoId"), Index("menuItemId")]
)
data class PedidoItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pedidoId: Long,
    val menuItemId: Long,
    val cantidad: Int,
    val precioUnit: Double
)
