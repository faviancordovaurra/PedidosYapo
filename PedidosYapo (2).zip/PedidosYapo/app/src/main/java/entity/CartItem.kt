package com.pedidosyapo.entity

import androidx.room.*

@Entity(tableName = "cartitem")
data class CartItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productoId: Long,
    val cantidad: Int
)
