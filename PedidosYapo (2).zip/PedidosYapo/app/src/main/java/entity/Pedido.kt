package com.pedidosyapo.entity



import androidx.room.*

@Entity(tableName = "pedido")
data class Pedido(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val restauranteId: Long,
    val fecha: String,
    val total: Double,
    val direccionEntrega: String,
    val estado: String
)
