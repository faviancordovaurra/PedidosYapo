package com.pedidosyapo.viewmodel


import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.pedidosyapo.repository.RestaurantesRepository

class RestauranteViewModelFactory(private val repository: RestaurantesRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RestauranteViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return RestauranteViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
