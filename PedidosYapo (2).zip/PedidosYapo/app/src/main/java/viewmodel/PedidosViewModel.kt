package com.pedidosyapo.viewmodel


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.Pedido
import com.pedidosyapo.repository.PedidosRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PedidosViewModel(
    private val repo: PedidosRepository
) : ViewModel() {

    private val _pedidos = MutableStateFlow<List<Pedido>>(emptyList())
    val pedidos: StateFlow<List<Pedido>> = _pedidos.asStateFlow()

    init {
        viewModelScope.launch { load() }
    }

    private suspend fun load() {
        _pedidos.value = repo.getAllPedidos()   // ajusta si tu repo expone Flow
    }

    fun agregar(
        restauranteId: Long,
        fecha: String,
        total: Double,
        direccionEntrega: String,
        estado: String = "PENDIENTE"
    ) = viewModelScope.launch {
        repo.insertPedido(
            Pedido(
                restauranteId = restauranteId,
                fecha = fecha,
                total = total,
                direccionEntrega = direccionEntrega,
                estado = estado
            )
        )
        load()
    }

    fun eliminar(p: Pedido) = viewModelScope.launch {
        repo.deletePedido(p)
        load()
    }
}
