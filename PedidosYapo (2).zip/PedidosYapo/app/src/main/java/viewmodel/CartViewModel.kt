package com.pedidosyapo.viewmodel


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.CartItem
import com.pedidosyapo.repository.CartRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CartViewModel(private val repository: CartRepository) : ViewModel() {

    val items: StateFlow<List<CartItem>> =
        repository.getAll()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val total: StateFlow<Double> =
        repository.total()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    fun deleteById(id: Long) {
        viewModelScope.launch { repository.deleteById(id) }
    }
}
