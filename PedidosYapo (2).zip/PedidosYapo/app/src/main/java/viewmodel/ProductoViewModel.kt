package com.pedidosyapo.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.Producto
import com.pedidosyapo.repository.ProductosRepository
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProductoViewModel(
    private val repo: ProductosRepository
) : ViewModel() {

    // Lista reactiva de productos desde el repo
    val productos: StateFlow<List<Producto>> =
        repo.getAll().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000),
            initialValue = emptyList()
        )

    fun agregar(nombre: String, precio: Double) = viewModelScope.launch {
        repo.insert(Producto(nombre = nombre, precio = precio))
        // No hace falta “recargar”: productos emite tras el insert.
    }

    fun eliminar(p: Producto) = viewModelScope.launch {
        repo.delete(p)
        // Igual: el flujo vuelve a emitir tras el delete.
    }
}
