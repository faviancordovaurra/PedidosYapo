package com.pedidosyapo.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pedidosyapo.entity.Restaurante
import com.pedidosyapo.repository.RestaurantesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class RestauranteViewModel(private val repository: RestaurantesRepository) : ViewModel() {

    private val _restaurantes = MutableStateFlow<List<Restaurante>>(emptyList())
    val restaurantes: StateFlow<List<Restaurante>> = _restaurantes

    init {
        cargarRestaurantes()
    }

    private fun cargarRestaurantes() {
        viewModelScope.launch {
            _restaurantes.value = repository.getAllRestaurantes()
        }
    }

    fun agregar(nombre: String, direccion: String, telefono: String) {
        val nuevo = Restaurante(id = 0, nombre = nombre, direccion = direccion, telefono = telefono)
        viewModelScope.launch {
            repository.insertRestaurante(nuevo)
            cargarRestaurantes()
        }
    }

    fun eliminar(restaurante: Restaurante) {
        viewModelScope.launch {
            repository.deleteRestaurante(restaurante)
            cargarRestaurantes()
        }
    }
}
