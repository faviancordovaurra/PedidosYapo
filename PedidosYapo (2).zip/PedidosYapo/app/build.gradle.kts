plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp") version "2.0.21-1.0.25"
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21"
}

android {
    namespace = "com.pedidosyapo"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pedidosyapo"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures { compose = true }

    // Si usas el plugin compose de Kotlin 2.0.21, puedes mantener esto
    composeOptions { kotlinCompilerExtensionVersion = "1.7.3" }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

kotlin { jvmToolchain(17) }

dependencies {
    // ===== Compose BOM (recomendado) =====
    implementation(platform("androidx.compose:compose-bom:2024.10.00"))

    // Core Compose (sin versiones explícitas, las pone el BOM)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.material3:material3")

    // Navegación Compose
    implementation("androidx.navigation:navigation-compose:2.8.3")

    // Activity & Lifecycle
    implementation("androidx.activity:activity-compose:1.9.3") // puedes dejar 1.9.2 si prefieres
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6") // <- útil para collectAsStateWithLifecycle

    // ROOM
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // (Opcional, si luego usas ubicación)
    // implementation("com.google.android.gms:play-services-location:21.3.0")

    // Debug / test
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
    arg("room.incremental", "true")
    arg("room.generateKotlin", "true")
}
